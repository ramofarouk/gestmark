# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.contrib import admin
from Market.models import Article
from Market.models import Categorie
from Market.models import Client
from Market.models import AchatArticle


class ArticleShowing(admin.ModelAdmin):
    list_display = ('title', 'price', 'count', 'categorie')


class CategorieShowing(admin.ModelAdmin):
    list_display = ('title', 'description')


class ClientShowing(admin.ModelAdmin):
    list_display = ('first_name', 'last_name')


admin.site.register(Article, ArticleShowing)
admin.site.register(Categorie, CategorieShowing)
admin.site.register(Client, ClientShowing)
admin.site.register(AchatArticle)
