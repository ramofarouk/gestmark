# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models


class Categorie(models.Model):
    title = models.CharField(max_length=255)
    description = models.TextField()
    date_created = models.DateTimeField(auto_now_add=True)
    last_modified = models.DateTimeField(auto_now=True)
    is_draft = models.BooleanField(default=True)

    def __str__(self):
        return self.title

    def __unicode__(self):
        return self.title


class Article(models.Model):
    title = models.CharField(max_length=255)
    description = models.TextField()
    price = models.DecimalField(decimal_places=2, max_digits=20)
    count = models.IntegerField(default=1)
    categorie = models.ForeignKey(Categorie, on_delete=models.CASCADE)
    date_created = models.DateTimeField(auto_now_add=True)
    last_modified = models.DateTimeField(auto_now=True)
    is_draft = models.BooleanField(default=True)

    def __str__(self):
        return self.title

    def __unicode__(self):
        return self.title

    def getPrice(self):
        return self.price


class Client(models.Model):
    first_name = models.CharField(max_length=255)
    last_name = models.CharField(max_length=255)
    date_created = models.DateTimeField(auto_now_add=True)
    last_modified = models.DateTimeField(auto_now=True)
    is_draft = models.BooleanField(default=True)

    def __str__(self):
        return self.first_name + " " + self.last_name

    def __unicode__(self):
        return self.first_name + " " + self.last_name


class AchatArticle(models.Model):
    article = models.ForeignKey(Article, on_delete=models.CASCADE)
    client = models.ForeignKey(Client, on_delete=models.CASCADE)
    nombre = models.IntegerField(default=1)
    price_total = models.DecimalField(decimal_places=2, max_digits=20 )
    price_unit = models.DecimalField(decimal_places=2, max_digits=20)
    date_buy = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.client

    def __unicode__(self):
        return self.client
